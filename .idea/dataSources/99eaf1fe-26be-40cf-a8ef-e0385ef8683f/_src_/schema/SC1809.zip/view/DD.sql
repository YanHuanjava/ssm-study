CREATE VIEW DD AS ( --模拟出24个小时时段

SELECT (trunc(to_date('2019-01-20', 'yyyy-mm-dd')) + (LEVEL - 1) / 24) one_hour_1,
(trunc(to_date('2019-01-20', 'yyyy-mm-dd')) + LEVEL / 24) one_hour_2 FROM dual CONNECT BY LEVEL <= 24

)
/
